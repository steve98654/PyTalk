#!/usr/bin/env python3

# Assume outline-mode input.
# Ignore sections under (any level of) headings starting with 'hide'.
# Lines that start with '#' are turned into display text
# Lines with '##' show up as comments in code, not in .pdf
# An embedded '#' triggers no change
# Private comments starting with '###' are dropped. - out of date?, see '##P' in code below

# Perhaps trigger sections off of capitalized headings.

import IPython.nbformat as nbformat
import IPython.nbformat.v4.nbbase as nbbase
import logging
import sys
import enum
import os.path
from string import Template
import re
import subprocess

logging.basicConfig(filename='log.txt', level=logging.DEBUG)

INPUT_FILE = '../outline201.otl'
INPUT_FILE = 'outline201.otl'
# INPUT_FILE = '../short.otl'
CONVERT = False
CONVERT = True

IGNORE_HEADINGS = [ h.lower() for h in [
    'HIDE',
    'TODO',
    'Speaker',
]]

def ignore_heading(heading):
    heading = heading.lower()
    return any([heading.startswith(ignore) for ignore in IGNORE_HEADINGS])

def sections(iterable):
    """Return (level, heading, text) split by outline-mode"""
    level = 0
    result = []
    for lineno, line in enumerate(iterable):
        if '\t' in line:
            raise ValueError('Tab at line {}: {}'
                             .format(lineno, line))
        if line.startswith('# slide'):
            continue
        if line.startswith('###'):
            continue
        if line.startswith('# restart'):
            line = '  Restart Python to unclutter the namespace.'
        if line.strip() == '#':  # For '    #' indents in classes.
            continue
        if line.startswith('*'):
            if level:                  # not first time
                yield lineno, level, heading, result
            stars, heading = line.split(' ', 1)
            heading = heading.rstrip('\n')
            level = stars.count('*')
            result = []
        else:
            result.append(line.rstrip('\n'))
    yield lineno, level, heading, result

def public_sections(iterable):
    hide_threshold = 1
    for lineno, level, heading, section in sections(iterable):
        if level > hide_threshold:
            pass                        # skip this section
        elif ignore_heading(heading):
            hide_threshold = level
        else:
            hide_threshold = sys.maxsize     # we're back out to a public level
            yield lineno, level, heading, section

# or http://eli.thegreenplace.net/2009/08/29/co-routines-as-an-alternative-to-state-machines/
State = enum.Enum('State', 'start ignore blank comment slide_start slide_end text code code_cont_indent code_cont_noindent')

def get_state(line):
    if not line:
        return State.blank
    if line.startswith('###'):
        return State.ignore
    if line.startswith('#'):
        return State.comment
    if line.startswith('.slide_start'):
        return State.slide_start
    if line.startswith('.slide_end'):
        return State.slide_end
    if line.startswith('    '):
        return State.code_cont_indent
    if line.startswith('  '):
        return State.text
    if line.startswith(' '):
        return State.code_cont_noindent
    return State.code
        
def split_blocks(lines):
    """
    A block is:
    - a block of code (usually one line)
    - indented text (until the next block)
    - blank lines
    - comments
    """
    block = []
    old, state = State.start, State.start
    iterator = iter(lines)
    while True:
        line = next(iterator)
        if get_state(line) == State.ignore:
            continue
        old = state
        state = get_state(line)
        logging.info('Line: {!r} -> {} (old {})'.format(line, state, old))
        if (not (old == state == State.code) and
            (old == State.start or
             state in (State.code_cont_indent, State.code_cont_noindent, old))
        ):
            if state == State.text:
                line = line.lstrip()
            if state == State.code_cont_noindent:
                if not line.startswith('  '):   # Only strip single space, indented leave as is.
                    line = line.lstrip()
            block.append(line)
        else:
            logging.info('Yield {} block {!r}'.format(old, block))
            yield old, block
            block = [line]
            if old == State.slide_start:
                # block = []  # Drop '.slide_start' - already emitted
                while True:
                    line = next(iterator)
                    state = get_state(line)
                    if state == State.slide_end:
                        break  # next time around loop will issue State.slide_end, block
                    else:
                        line = line.replace('``', '`')
                        line = line.replace('::', ':')
                        block.append(line)
    yield state, block


def filter_multiple_blanks(pairs):
    # http://stackoverflow.com/questions/3460161/remove-adjacent-duplicate-elements-from-a-list
    prev = (object(), object())
    for item in pairs:
        if (item[0] == State.blank and prev[0] == State.blank):
            pass
        else:
            prev = item
            yield item
            

def is_texty(block):
    state, content = block
    return state in (State.text, State.comment, State.slide_start)

def filter_blanks_by_texts(pairs):
    """Remove a blank with text before or after it."""
    # text/blank or blank/text
    # import pdb; pdb.set_trace()
    iterator = filter_multiple_blanks(pairs)
    elements = []
    try:
        for i in range(2):
            elements.append(next(iterator))
        while True:
            if (is_texty(elements[0]), elements[1][0]) == (True, State.blank):
                pass
            else:
                if not (elements[0][0], is_texty(elements[1])) == (State.blank, True):
                    yield elements[0]
                elements[0] = elements[1]
            del elements[1]
            elements.append(next(iterator))
    except StopIteration:
        for el in elements:
            yield el


def UNUSED_convert_slides(section):
    """
    Convert .slide_start/.slide_end sections by indenting their contents.
    """
    slide = False
    for line in section:
        if line.startswith('.slide_start'):
            slide = True
            continue
        if line.startswith('.slide_end'):
            slide = False
            continue
        if slide:
            if line.startswith('.. include::'):
                continue
            yield '  ' + line
        else:
            yield line


IPYTHON = 'ipython3'
if sys.platform == 'win32':
    IPYTHON = 'c:/Anaconda3/Scripts/ipython.exe'

EXTRA_ARGS = [
#    '--to notebook --execute',
   '',
]

def convert_notebook(notebook_name, verbose=False):
    commands = []
    for extra_args in EXTRA_ARGS:
        commands.append('{} nbconvert {} {}'.format(IPYTHON, extra_args, notebook_name))
    # commands.append('{} nbconvert {}'
    #                 .format(IPYTHON, '{}.nbconvert{}'.format(*os.path.splitext(notebook_name))))
    for cmd in commands:
        __ = subprocess.check_output(cmd, stderr=subprocess.STDOUT, shell=True)
        if verbose:
            print('Done', cmd)
    

VIDEO_SCRIPT_COLUMN =[
    'Seg #',                              # 1..N throughout
    'Part (or Chapter)',                  # Chapter == '*'
    'Segment Title',                      # '**'
    'Segment Description',
    # 'Run Time (minutes)',
    ]

def main(sections):
    notebooks = []
    section_lines = 0
    LENGTH = 50
    length_format = '{:3d}>{} {}\n'
    lengths = open('lengths.txt', 'w')
    lengths.write(length_format.format(0, LENGTH, '.' * LENGTH))
    video_rows = []
    section_number_1 = section_number_2 = 1
    for count, (lineno, level, heading, section) in enumerate(public_sections(open(INPUT_FILE))):
        if level == 1:
            nb = nbbase.new_notebook()
            nb.cells.append(nbbase.new_markdown_cell(source='# {1} '.format(section_number_1, heading)))
            section_number_1 += 1
            notebooks.append((heading, section_lines, nb))
            section_lines = 0
            chapter = heading
        if level == 2:
            # print(2, heading)
            nb.cells.append(nbbase.new_markdown_cell(source='### {2}'
                                                    .format(section_number_1, section_number_1, heading)))
            section_number_2 += 1
            segment_title = heading
        if heading == 'Video':
            assert level == 3
            video_rows.append((chapter, segment_title, section))
            continue
        for state, block in filter_blanks_by_texts(split_blocks(section)):
            section_lines += len(block)
            if state in (State.code, State.code_cont_noindent, State.code_cont_indent):
                for line in block:
                    if len(line) > LENGTH:
                        lengths.write(length_format.format(lineno, LENGTH, line))
                nb.cells.append(nbbase.new_code_cell(source='\n'.join(block)))
            if state == State.blank:
                nb.cells.append(nbbase.new_markdown_cell(source=' '))
            if state == State.comment:
                # strip '# ' from comments
                nb.cells.append(nbbase.new_markdown_cell(source='\n'.join([line[2:] for line in block])))
            if state in (State.text, State.slide_end):
                nb.cells.append(nbbase.new_markdown_cell(source='\n'.join(block)))
    with open('video.txt', 'w') as vfile:
        segment_number = 0
        for row in video_rows:
            segment_number += 1
            #print(segment_number)
            #print(row)
            chapter, segment_title, section = row
            description = ' '.join(section)
            # vfile.write('\t'.join([str(segment_number), chapter, segment_title, description]) + '\n')
            segment_title = re.sub(r'^\d+\.\d+ ', '', segment_title)
            vfile.write('\t'.join([segment_title, description]) + '\n')
    if True:
        complete_notebook_name = 'build/Python-Epiphanies-All.ipynb'
        complete_nb = nbbase.new_notebook()
        total_lines = total_cells = 0
        for count, (heading, nb_lines, nb) in enumerate(notebooks):
            total_lines += nb_lines
            total_cells += len(nb.cells)
            if not sections or count in sections:
                notebook_name = ('build/Python-Epiphanies-{:02d}-{}.ipynb'
                                 .format(count, heading.replace(' ', '-')))
                with open(notebook_name, 'w') as notebook_file:
                    notebook_file.write(nbformat.writes(nb))
                print('{:3d}/{:3d} cells/lines: {}'.format(len(nb.cells), nb_lines, notebook_name))
                if CONVERT:
                    convert_notebook(notebook_name, verbose=bool(sections))
            complete_nb.cells.extend(nb.cells)
        if not sections:
            with open(complete_notebook_name, 'w') as complete_file:
                complete_file.write(nbformat.writes(complete_nb))
            if CONVERT:
                convert_notebook(complete_notebook_name)
            print('Total {:3d}/{:3d} cells/lines'.format(total_cells, total_lines))


if __name__ == '__main__':
    main([int(a) for a in sys.argv[1:]])
