def double(val, n=3):
    for i in range(n):
        val = val + val
        yield val
