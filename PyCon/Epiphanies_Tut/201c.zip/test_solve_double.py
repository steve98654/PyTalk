from double import double

def test_double():
    assert list(double('.')) == ['..', '....', '........']
    assert list(double('s.', 2)) == ['s.s.', 's.s.s.s.']
    assert list(double(1)) == [2, 4, 8]
    assert list(double([1, 2], n=2)) == [
        [1, 2, 1, 2], [1, 2, 1, 2, 1, 2, 1, 2]]
