def g(a, b, *args, c=None):
    print('a: {!r}, b: {!r}, '
        'args: {!r}, c: {!r}'
        .format(a, b, args, c))

print(g.__defaults__)
print(g.__kwdefaults__)
print(g(1, 2, 3, 4))
print(g(1, 2, 3, 4, c=True))
