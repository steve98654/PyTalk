def add(first, second):
    return first + second

def trace_function(f):
    """Add tracing before and after a function"""
    def new_f(*args):
        """The new function"""
        print(
            'Called {}({!r})'
            .format(f, *args))
        result = f(*args)
        print('Returning', result)
        return result
    return new_f

traced_add = trace_function(add)

print(traced_add(2, 3))

def trace_function(f):
    """Add tracing before and after a function"""
    def new_f(*args):
        """The new function"""
        print(
            'Called {}{!r}'
            .format(f, args))
        result = f(*args)
        print('Returning', result)
        return result
    return new_f

traced_add = trace_function(add)

print(traced_add(2, 3))

import functools
def memoize(f):
    print('Called memoize({!r})'.format(f))
    cache = {}
    @functools.wraps(f)
    def memoized_f(*args):
        print('Called memoized_f{!r}'.format(args))
        if args in cache:
            print('Cache hit!')
            return cache[args]
        if args not in cache:
            result = f(*args)
            cache[args] = result
            return result
    return memoized_f

@memoize
def add(first, second):
    """Return the sum of two arguments."""
    return first + second
print(add(2, 3))
print(add(4, 5))
print(add(2, 3))
