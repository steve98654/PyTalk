#!/usr/bin/env python3

import pytest

import otl2nb as sut
from otl2nb import State

def get_states(pairs):
    return [state for state, block in pairs]

def test_states():
    assert sut.get_state('') == sut.State.blank
    assert sut.get_state('#') == sut.State.comment
    assert sut.get_state(' ') == sut.State.text
    assert sut.get_state('a') == sut.State.code

DATA = """
b1
b2
b3
    b3.1
    b3.2
b4
# comment1
# commment1

# comment2

  text1
  text1

  text2

""".splitlines()[1:]

EXPECTED = [State.comment, State.slide_start, State.slide_end, State.blank]

def test_1():
    assert get_states(sut.split_blocks(DATA)) == EXPECTED

def test_2():
    assert get_states(sut.split_blocks(
        ['x = 1',
         'def test1():',
         "    print('In test1 x ==', x)",
         '',
         'test1()'])) == [State.code, State.code_cont, State.blank]


DATA = """
# slides (5)
.slide_start

A *namespace* is a mapping from valid identifier names to objects.
Think of it as a dictionary.
.slide_end

a = 3
""".splitlines()[1:]

def test_3():
    assert get_states(sut.split_blocks(DATA)) == [
        State.comment, State.slide_start, State.slide_end, State.blank]

STATE_CHARS = {
    'b': State.blank,
    'T': State.text,
    'S': State.slide_start,
    'C': State.code,
}

def convert_ch_to_state(sequence):
    return [STATE_CHARS[ch] for ch in sequence]


def test_filter_multiple_blanks():
    for i in range(6):
        blanks = 'b' * i
        expected = ([State.blank] if i else [])
        assert get_states(sut.filter_multiple_blanks(zip(convert_ch_to_state(blanks), range(i)))) == expected

# Test: Expected, see STATE_CHARS above for mapping
BLANK_TEXT_DATA = """
T: T
TT: TT
TTT: TTT
TTTT: TTTT
TTTTT: TTTTT
bT: T
bbT: T
bTb: T
bbTbb: T
bbTTbb: TT
Tb: T
Tbb: T
TbT: TT
TbTb: TT
bTTTT: TTTT
bbTTTT: TTTT
bbbTTTT: TTTT
bbbbTTTT: TTTT
bbbbT: T
bTbT: TT
TbTbT: TTT
bbbb: b
bTC: TC
TbC: TC
CbS: CS
""".splitlines()[1:]

@pytest.fixture(params=BLANK_TEXT_DATA)
def blank_text_data(request):
    return request.param

def test_filter_blanks_by_texts2(blank_text_data):
    if blank_text_data.startswith('#'):
        return
    test, expected = [convert_ch_to_state(side) for side in blank_text_data.split(': ')]
    # pytest.set_trace()
    result = get_states(sut.filter_blanks_by_texts(zip(test, range(100))))
    print('Test:', test)
    print('Expected:', expected)
    print('Result:', result)
    assert result == expected
    
# def test_filter_blanks_by_texts():
#     for line in BLANK_TEXT_DATA:
#         if line.startswith('#'):
#             continue
#         test, expected = [convert_ch_to_state(side) for side in line.split(': ')]
#         # pytest.set_trace()
#         result = get_states(sut.filter_blanks_by_texts(zip(test, range(100))))
#         print('Result:', result)
#         assert result == expected
    
    


