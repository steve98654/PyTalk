Files for Python Epiphanies presented at PyCon 2016 by Stuart Williams

To maximize your learninig in the exercises I strongly recommend that
you use the file Python-Epiphanies-All.html and type the code into the
Python REPL yourself, rather than just reading and executing the code
in the IPython notebook (Python-Epiphanies-All.ipynb).

The files Python-Epiphanies-00*..07*.ipynb are smaller IPython notebook
files by section because the large IPython notebook file may cause your browser to crash.

The gaps in the section numbers are intentional in order to match the
Python Epiphanies O'Reilly video at http://shop.oreilly.com/product/0636920039815.do
