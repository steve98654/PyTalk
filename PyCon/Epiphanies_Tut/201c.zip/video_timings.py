import re

lines = [line for line in open('video-timings.txt').readlines()
         if not line.strip().startswith('#')]

text = ''.join(lines)
print(sum([int(m) * 60 + int(s)
           for (m, s) in
           re.findall(r' (\d{2})m (\d{2})s', text)])/60)
