import functools
def trace_function(func):  # Same as earlier
    """Add tracing before and after a function"""
    @functools.wraps(func)
    def new_func(*args):
        """The new function"""
        print(
            'Called {}({!r})'
            .format(func, *args))
        result = func(*args)
        print('Returning', result)
        return result
    return new_func

def count_function_calls(func):
    """Count calls to the function"""
    count = 0
    @functools.wraps(func)
    def new_func(*args):
        nonlocal count
        count += 1
        return func(*args)

@count_function_calls
@trace_function
def plural(s):
    return s + 's'

plural('dog')
plural('cat')
print(plural.count)

@trace_function
@count_function_calls
def plural(s):
    return s + 's'

plural('dog')
plural('cat')
print(plural.count)
